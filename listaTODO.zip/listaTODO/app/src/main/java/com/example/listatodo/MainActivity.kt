package com.example.listatodo

import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var nowyZadanie: EditText
    private lateinit var dodajButton: Button
    private lateinit var listaZadan: ListView

    private val zadania = mutableListOf<String>()

    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nowyZadanie = findViewById(R.id.nowyZadanie)
        dodajButton = findViewById(R.id.dodajButton)
        listaZadan = findViewById(R.id.listaZadan)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, zadania)
        listaZadan.adapter = adapter

        dodajButton.setOnClickListener {
            dodajZadanie()
        }

        listaZadan.setOnItemClickListener { _, _, pozycja, _ ->
            usunZadanie(pozycja)
        }
    }

    private fun dodajZadanie() {
        val tekst = nowyZadanie.text.toString()

        if (tekst.isEmpty()) {
            Toast.makeText(this, "Wpisz jakieś zadanie!", Toast.LENGTH_SHORT).show()
            return
        }

        zadania.add(tekst)
        adapter.notifyDataSetChanged()

        nowyZadanie.text.clear()
    }

    private fun usunZadanie(pozycja: Int) {
        zadania.removeAt(pozycja)
        adapter.notifyDataSetChanged()
    }
}