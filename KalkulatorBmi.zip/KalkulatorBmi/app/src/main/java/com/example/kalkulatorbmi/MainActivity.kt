package com.example.kalkulatorbmi

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var liczba1: EditText
    private lateinit var liczba2: EditText
    private lateinit var button: Button
    private lateinit var wynik: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        liczba1 = findViewById(R.id.liczba1)
        liczba2 = findViewById(R.id.liczba2)
        button = findViewById(R.id.button)
        wynik = findViewById(R.id.wynik)

        button.setOnClickListener {
            obliczBMI()
        }
    }

    private fun obliczBMI() {
        val wagaText = liczba1.text.toString()
        val wzrostText = liczba2.text.toString()

        if (wagaText.isEmpty() || wzrostText.isEmpty()) {
            wynik.text = "Wypełnij oba pola!"
            return
        }

        val waga = wagaText.toDouble()
        val wzrostCm = wzrostText.toDouble()

        val wzrostM = wzrostCm / 100.0
        val bmi = waga / (wzrostM * wzrostM)

        wynik.text = "Twoje BMI: %.2f".format(bmi)
    }
}