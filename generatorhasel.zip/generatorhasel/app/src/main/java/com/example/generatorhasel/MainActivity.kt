package com.example.generatorhasel

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var podajDlugosc: EditText
    private lateinit var guzik: Button
    private lateinit var wynik: TextView

    private val znaki = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        podajDlugosc = findViewById(R.id.podajDlugosc)
        guzik = findViewById(R.id.guzik)
        wynik = findViewById(R.id.wynik)

        guzik.setOnClickListener {
            generujHaslo()
        }
    }

    private fun generujHaslo() {
        val dlugoscText = podajDlugosc.text.toString()

        if (dlugoscText.isEmpty()) {
            wynik.text = "Podaj długość hasła!"
            return
        }

        var dlugosc = dlugoscText.toInt()

        if (dlugosc > 20) {
            dlugosc = 20
        }
        
        if (dlugosc < 1) {
            wynik.text = "Długość musi być większa od 0!"
            return
        }

        val haslo = StringBuilder()

        for (i in 1..dlugosc) {
            val losowyIndeks = znaki.indices.random()
            val losowyZnak = znaki[losowyIndeks]
            haslo.append(losowyZnak)
        }

        wynik.text = haslo.toString()
    }
}