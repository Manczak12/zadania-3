package com.example.pkt

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var wynikDR1: TextView
    private lateinit var wynikDR2: TextView
    private lateinit var button: Button
    private lateinit var button2: Button

    private var punktyDruzyna1 = 0
    private var punktyDruzyna2 = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wynikDR1 = findViewById(R.id.wynikDR1)
        wynikDR2 = findViewById(R.id.wynikDR2)
        button = findViewById(R.id.button)
        button2 = findViewById(R.id.button2)

        wynikDR1.text = punktyDruzyna1.toString()
        wynikDR2.text = punktyDruzyna2.toString()

        button.setOnClickListener {
            punktyDruzyna1++
            wynikDR1.text = punktyDruzyna1.toString()
        }

        button2.setOnClickListener {
            punktyDruzyna2++
            wynikDR2.text = punktyDruzyna2.toString()
        }
    }
}